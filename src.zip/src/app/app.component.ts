import { Component,OnInit } from '@angular/core';
import { StockService } from './stock.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'stockManagement-frontend';
  private detailsForm: any | undefined;
  companyCode:string;

  activatedRoute: any;
  router: any;
  constructor(
    private stockService: StockService
  ) {}

  getValues(data:any){
    this.companyCode=data.companyCode;
    console.warn(this.companyCode);
    this.stockService.getDetailsByCompanyCode(this.companyCode)
    .subscribe(Response=>{
      console.info(Response)
      this.detailsForm= Response;
      
    })
  }
  
}





