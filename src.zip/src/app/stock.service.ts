import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class StockService {
  public baseUrl = 'http://localhost:9191/api/v1.0/market/stock';
 
  constructor(private http:HttpClient) { }

  createStock(stock: Object): Observable<Object> {
    console.log(stock);
    return this.http.post(`${this.baseUrl}`+'/add/',stock);
  }

  getDetailsByCompanyCode(companyCode:string): Observable<Object>{
    console.warn("************* "+companyCode);
    return this.http.get(`${this.baseUrl}/stockInfo/${companyCode}`);
  }
}
