export class Company {
   
    companyCode: string | undefined;
    companyName: string | undefined;
    companyCEO: string | undefined;
    companyTurnOver: string | undefined;
    companyWebsite: string | undefined;
    stockExchange: string | undefined;

}
