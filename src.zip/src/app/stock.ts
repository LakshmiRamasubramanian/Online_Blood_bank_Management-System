export class Stock {

    
        
        price: number|undefined;
        companyCode: string | undefined;
    
    
}
