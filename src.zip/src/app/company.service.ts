import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CompanyService {
  public baseUrl = 'http://localhost:9191/api/v1.0/market/company';
  constructor(private http:HttpClient) { }

  createCompany(company: Object): Observable<Object> {
    console.log(company);
    return this.http.post(`${this.baseUrl}`+'/register',company);
  }
}
