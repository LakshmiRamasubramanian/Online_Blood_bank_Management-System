import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CompanyComponent } from './company/company.component';
import { StockComponent } from './stock/stock.component';

const routes: Routes = [
  { path: 'Company', component: CompanyComponent },
  { path: 'Stock', component: StockComponent},
  {path: 'search', component:StockComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
