import { Component, OnInit } from '@angular/core';
import { Company } from '../company';
import { CompanyService } from '../company.service';

@Component({
  selector: 'app-company',
  templateUrl: './company.component.html',
  styleUrls: ['./company.component.css']
})
export class CompanyComponent implements OnInit {
  company:Company= new Company();
  constructor(private companyService: CompanyService) { }

  ngOnInit(){
  }
  createCompany(){
    console.log(this.company);
    this.companyService.createCompany(this.company)
    .subscribe(data => console.log(data), error => console.log(error));
     this.company=new Company();
  }

  onSubmit() {
  
    this.createCompany();
  }

}
