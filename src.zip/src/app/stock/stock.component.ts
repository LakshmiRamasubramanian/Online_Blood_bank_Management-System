import { Component, OnInit } from '@angular/core';
import { Stock } from '../stock';
import { StockService } from '../stock.service';

@Component({
  selector: 'app-stock',
  templateUrl: './stock.component.html',
  styleUrls: ['./stock.component.css']
})
export class StockComponent implements OnInit {
  stock:Stock= new Stock();
  private detailsForm: Object | undefined;
  companyCode:string;
  constructor(private stockService: StockService) { }


  ngOnInit(): void {
  }


  createStock(){
    console.log(this.stock);
    this.stockService.createStock(this.stock)
    .subscribe(data => console.log(data), error => console.log(error));
     this.stock=new Stock();
  }


  getValues(data:any){
    this.companyCode=data.companyCode;
    console.warn(this.companyCode);
    this.stockService.getDetailsByCompanyCode(this.companyCode)
    .subscribe((data : any)=>{
      console.warn(data);
      this.detailsForm= data;
      })
    }


  onSubmit() {
   this.createStock();
  }


}
